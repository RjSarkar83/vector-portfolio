# AV — Red Minimal Branding Mockups (158 SVG)

`Branding Mockup Guide` ke **har AI prompt** se ek professional SVG mockup — red minimal theme
(**#E5322D** / **#1A1518** / **#F3F0EA**) me, teeno logos ke saath.

## Files
- `index.html` — sabhi 158 mockups ka filterable gallery (category + logo + search)
- `svg/` — 158 individual SVG files (1600 × 1000, print-safe vector)
- `assets/` — vectorized logo paths + colour PNGs
- `AV_Red_Minimal_Mockups.zip` — poora pack

## Logo rotation
- `AV_Logo_001` (owl/mask) · `AV_Logo_002` (A-compass) · `AV_Logo_003` (gear)
- Har mockup me round-robin: mockup #1 → logo 01, #2 → logo 02, #3 → logo 03 …

## Har SVG me
1. Header — brand + category + logo id
2. Scene — us prompt ka vector mockup (size/material/lighting/camera ke hisaab se)
3. Footer — Title, Size, Material, Lighting, View, Elements + **full AI prompt line**

## Categories (18) × counts
- Retail Store: 12
- Office: 10
- Showroom: 10
- Mall: 12
- Common: 6
- Exhibition / Expo: 9
- Events: 12
- POSM & Visual Merchandising: 11
- Restaurant / Cafe / QSR: 6
- Brand Identity: 8
- Industry / Special Spaces: 10
- Stadium / Sports Venue: 15
- Signage Specials: 6
- Airport Lounge / Aviation: 7
- Warehouse / Factory / Industrial: 6
- Temple / Trust / NGO: 8
- Safety and Accessibility: 5
- Franchise / Rollout Programs: 5
